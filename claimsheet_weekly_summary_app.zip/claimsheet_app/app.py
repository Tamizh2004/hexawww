import io
from datetime import datetime

import openpyxl
import pandas as pd
import streamlit as st
from openpyxl.styles import Alignment, Border, Font, Side
from openpyxl.utils import get_column_letter

st.set_page_config(page_title="Claimsheet Weekly Summary", page_icon="📊", layout="centered")

# ---------------------------------------------------------------------------
# Config: which cells on every employee sheet hold the weekly numbers
# ---------------------------------------------------------------------------
BILLED_CELLS = ["D3", "J3", "Q3", "Y3", "AE3"]       # W1 - W5 Billed
NON_BILLED_CELLS = ["D4", "J4", "Q4", "Y4", "AE4"]   # W1 - W5 Non-billed
TOTAL_CELLS = ["D5", "J5", "Q5", "Y5", "AE5"]        # W1 - W5 Total (Billed + Non-billed)
WEEK_LABELS = ["W1", "W2", "W3", "W4", "W5"]

# Sheets that are NOT individual employee sheets and must be skipped
SHEETS_TO_SKIP = {"master sheet", "details"}


def _clean(value):
    """Pass numbers through as-is; keep Excel error strings (e.g. '#REF!')
    visible instead of silently turning them into 0, and treat a truly
    empty cell as 0."""
    if value is None:
        return 0
    if isinstance(value, str) and value.strip().startswith("#"):
        return value  # surface the source error rather than hide it
    return value


def extract_employee_data(uploaded_file):
    """Read the uploaded claimsheet workbook and pull the weekly billed /
    non-billed numbers for every employee sheet."""
    wb = openpyxl.load_workbook(uploaded_file, data_only=True)

    rows = []
    skipped = []
    error_sheets = []
    for sheet_name in wb.sheetnames:
        if sheet_name.strip().lower() in SHEETS_TO_SKIP:
            continue

        ws = wb[sheet_name]

        try:
            billed = [_clean(ws[c].value) for c in BILLED_CELLS]
            non_billed = [_clean(ws[c].value) for c in NON_BILLED_CELLS]
            total = [_clean(ws[c].value) for c in TOTAL_CELLS]
        except Exception:
            skipped.append(sheet_name)
            continue

        if any(isinstance(v, str) for v in billed + non_billed + total):
            error_sheets.append(sheet_name)

        employee_name = sheet_name.strip()

        rows.append(
            {
                "Employee name": employee_name,
                **{f"Billable {w}": billed[i] for i, w in enumerate(WEEK_LABELS)},
                **{f"Non billable {w}": non_billed[i] for i, w in enumerate(WEEK_LABELS)},
                **{f"Total Billable {w}": total[i] for i, w in enumerate(WEEK_LABELS)},
            }
        )

    df = pd.DataFrame(rows)
    return df, skipped, error_sheets


def build_output_workbook(df: pd.DataFrame) -> bytes:
    """Build a formatted xlsx that mirrors the target layout:
    a two-row header with merged 'Billable' / 'Non billable' / 'Total Billable'
    groups (each separated by one blank spacer column, as in the reference
    screenshot), followed by one row per employee.
    """
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Weekly Summary"

    bold = Font(bold=True)
    center = Alignment(horizontal="center", vertical="center")
    thin = Side(style="thin", color="000000")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)

    # Column layout (1-indexed):
    # A            = Employee name
    # B-F          = Billable W1-W5
    # G            = blank spacer
    # H-L          = Non billable W1-W5
    # M            = blank spacer
    # N-R          = Total Billable W1-W5
    BILLABLE_START = 2
    NONBILLED_START = 8
    TOTAL_START = 14
    GAP_COLS = [7, 13]

    # --- Header row 1 ---
    ws.merge_cells("A1:A2")
    ws["A1"] = "Employee name"
    ws["A1"].font = bold
    ws["A1"].alignment = center

    def merge_group_header(start_col, label):
        start_letter = get_column_letter(start_col)
        end_letter = get_column_letter(start_col + 4)
        ws.merge_cells(f"{start_letter}1:{end_letter}1")
        cell = ws[f"{start_letter}1"]
        cell.value = label
        cell.font = bold
        cell.alignment = center

    merge_group_header(BILLABLE_START, "Billable")
    merge_group_header(NONBILLED_START, "Non billable")
    merge_group_header(TOTAL_START, "Total Billable")

    # --- Header row 2 (week labels) ---
    for i, w in enumerate(WEEK_LABELS):
        for start in (BILLABLE_START, NONBILLED_START, TOTAL_START):
            col = get_column_letter(start + i)
            ws[f"{col}2"] = w
            ws[f"{col}2"].font = bold
            ws[f"{col}2"].alignment = center

    # --- Data rows ---
    start_row = 3
    for r, row in enumerate(df.itertuples(index=False), start=start_row):
        ws[f"A{r}"] = row[0]
        for i in range(5):
            col_billed = get_column_letter(BILLABLE_START + i)
            col_nonbilled = get_column_letter(NONBILLED_START + i)
            col_total = get_column_letter(TOTAL_START + i)
            ws[f"{col_billed}{r}"] = row[1 + i]
            ws[f"{col_nonbilled}{r}"] = row[6 + i]
            ws[f"{col_total}{r}"] = row[11 + i]
            ws[f"{col_billed}{r}"].alignment = center
            ws[f"{col_nonbilled}{r}"].alignment = center
            ws[f"{col_total}{r}"].alignment = center

    last_col = TOTAL_START + 4  # R

    # --- Borders across the whole table (skip the blank spacer columns) ---
    last_row = start_row + len(df) - 1 if len(df) else 2
    for row_cells in ws.iter_rows(min_row=1, max_row=max(last_row, 2), min_col=1, max_col=last_col):
        for cell in row_cells:
            if cell.column in GAP_COLS:
                continue
            cell.border = border

    # --- Column widths ---
    ws.column_dimensions["A"].width = 22
    for i in range(5):
        ws.column_dimensions[get_column_letter(BILLABLE_START + i)].width = 10
        ws.column_dimensions[get_column_letter(NONBILLED_START + i)].width = 10
        ws.column_dimensions[get_column_letter(TOTAL_START + i)].width = 12
    for gap_col in GAP_COLS:
        ws.column_dimensions[get_column_letter(gap_col)].width = 3

    buffer = io.BytesIO()
    wb.save(buffer)
    buffer.seek(0)
    return buffer.getvalue()


# ---------------------------------------------------------------------------
# UI
# ---------------------------------------------------------------------------
st.title("📊 Claimsheet Weekly Summary Generator")
st.write(
    "Upload the monthly claimsheet workbook (the one with one tab per employee). "
    "This tool pulls each employee's **Billed**, **Non-billed**, and **Total Billable** "
    "hours for weeks W1–W5 straight from the fixed cells on every sheet, and produces a "
    "clean summary workbook formatted like the target layout."
)

with st.expander("Which cells are read from each employee sheet?"):
    st.markdown(
        """
| Week | Billed cell | Non-billed cell | Total billable cell |
|------|-------------|------------------|----------------------|
| W1 | D3 | D4 | D5 |
| W2 | J3 | J4 | J5 |
| W3 | Q3 | Q4 | Q5 |
| W4 | Y3 | Y4 | Y5 |
| W5 | AE3 | AE4 | AE5 |

Sheets named **Master Sheet** and **Details** are skipped automatically; every
other tab is treated as an employee sheet (its tab name becomes the employee
name).
        """
    )

uploaded_file = st.file_uploader("Upload claimsheet (.xlsx)", type=["xlsx"])

if uploaded_file is not None:
    with st.spinner("Reading claimsheet..."):
        try:
            df, skipped, error_sheets = extract_employee_data(uploaded_file)
        except Exception as e:
            st.error(f"Could not read this workbook: {e}")
            st.stop()

    if df.empty:
        st.warning("No employee sheets were found in this workbook.")
    else:
        st.success(f"Found {len(df)} employee sheet(s).")

        # Preview with a grouped header, similar to the target image
        preview_cols = pd.MultiIndex.from_tuples(
            [("", "Employee name")]
            + [("Billable", w) for w in WEEK_LABELS]
            + [("Non billable", w) for w in WEEK_LABELS]
            + [("Total Billable", w) for w in WEEK_LABELS]
        )
        preview_df = df.copy()
        preview_df.columns = preview_cols
        st.dataframe(preview_df, use_container_width=True)

        if skipped:
            st.caption(f"Skipped sheets that didn't match the expected format: {', '.join(skipped)}")

        if error_sheets:
            st.warning(
                "These sheets contain a formula error (e.g. `#REF!`) in the source "
                f"workbook itself, so that value is shown as-is rather than a number: "
                f"{', '.join(error_sheets)}. Fix the broken formula in the original "
                "claimsheet and re-upload to get a clean number."
            )

        output_bytes = build_output_workbook(df)
        today = datetime.now().strftime("%Y-%m-%d")
        st.download_button(
            label="⬇️ Download Weekly Summary (.xlsx)",
            data=output_bytes,
            file_name=f"Weekly_Summary_{today}.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
else:
    st.info("Waiting for a claimsheet upload.")
