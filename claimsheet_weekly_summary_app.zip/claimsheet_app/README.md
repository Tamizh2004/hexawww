# Claimsheet Weekly Summary Generator

A small Streamlit app that turns a monthly claimsheet workbook (one tab per
employee) into a clean weekly Billable / Non-billable summary workbook.

## What it does

1. You upload the claimsheet `.xlsx`.
2. The app goes through every sheet **except** `Master Sheet` and `Details`,
   treating each remaining tab as one employee (the tab name becomes the
   employee name).
3. From each employee sheet it reads:

   | Week | Billed cell | Non-billed cell | Total billable cell |
   |------|-------------|------------------|----------------------|
   | W1 | `D3` | `D4` | `D5` |
   | W2 | `J3` | `J4` | `J5` |
   | W3 | `Q3` | `Q4` | `Q5` |
   | W4 | `Y3` | `Y4` | `Y5` |
   | W5 | `AE3` | `AE4` | `AE5` |

4. It builds a new workbook with a two-row header (`Employee name` / merged
   `Billable`, `Non billable`, and `Total Billable` groups, each split into
   `W1`–`W5`) — the same layout as the target screenshot, now with the weekly
   total column added — and gives you a download button.

If a source cell contains a formula error (e.g. `#REF!`), the app shows it
as-is in that cell rather than silently turning it into a 0, and flags the
affected sheet so you know to fix the original file.

## Running locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

Then open the local URL Streamlit prints (usually `http://localhost:8501`).

## Deploying

This app has no external dependencies beyond the Python packages in
`requirements.txt`, so it deploys as-is to Streamlit Community Cloud, or any
host that can run `streamlit run app.py` (Docker, Render, etc.).

## Adjusting the cell mapping

If a future claimsheet template moves the weekly figures to different cells,
edit the two lists near the top of `app.py`:

```python
BILLED_CELLS = ["D3", "J3", "Q3", "Y3", "AE3"]
NON_BILLED_CELLS = ["D4", "J4", "Q4", "Y4", "AE4"]
TOTAL_CELLS = ["D5", "J5", "Q5", "Y5", "AE5"]
```
